#!/bin/sh
# 离线重放：建虚拟环境、装依赖、复算全部指标并与报告比对
set -e
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
[ -x .venv/bin/python ] || "$PY" -m venv .venv
.venv/bin/python -m pip install -q --disable-pip-version-check -r replay/requirements-replay.txt
PYTHONIOENCODING=utf-8 .venv/bin/python replay/replay.py
