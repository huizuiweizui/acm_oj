# 星语编程学伴 · 评测复现包

本包用来复核技术文档与测试报告里的四组消融实验数字。提供三级复现，**第一级不需要任何 API Key、网络或数据库**，约 1 分钟跑完：

| 级别 | 做什么 | 需要什么 | 预期结果 |
|---|---|---|---|
| **A 离线重放（推荐）** | 用录下来的 290 次大模型原始输出，原样执行评测代码，重新计算全部指标并与报告逐项比对 | Python 3.10+（实测 3.11、3.14），`replay/requirements-replay.txt` | 全部指标一致（见 §4） |
| B 单元测试 | 运行评测时版本源码自带的自动化测试 | 同上 + `source/requirements.txt`（不需要 MySQL）；可选 Node.js | 232 个通过，9 个跳过；32 个 skills 测试通过 |
| C 在线重跑 | 用你自己的大模型 Key 重新调用模型、重做实验 | OpenAI 兼容接口的 Key；一致性实验另需 Embedding Key | 数字会有正常浮动（模型输出有随机性），结论应一致 |

---

## 1. 快速开始（A 离线重放）

在本包根目录执行：

```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate      Linux / macOS:  source .venv/bin/activate
pip install -r replay/requirements-replay.txt
python replay/replay.py
```

Windows 也可以直接双击 `run_replay.bat`（Linux / macOS 用 `sh run_replay.sh`），脚本会建虚拟环境、装依赖并运行。

运行结束时打印结论，并写出：

- `replay_output/compare.md`：每个指标「报告值 / 复算值 / 是否一致」，以及逐行逐格的比对结果
- `replay_output/<实验>/summary.json`、`rows.csv`：复算出的结果，格式与 `results/` 相同

退出码 0 表示与报告一致，1 表示存在差异。

---

## 2. 目录结构

```
星语-评测复现包/
├── README.md                  本说明
├── run_replay.bat / .sh       一键离线重放
├── SHA256SUMS.txt             全部文件的校验和
├── source/                    评测时的源码（commit 427abcb，见 §6），仅后端，外加前后端规则一致性检查所需的 3 个前端文件
│   └── star/
│       ├── management/commands/star_eval.py   四组实验的代码（离线重放直接执行它）
│       ├── content/eval_cases.py              意图测试语句 50 条 + 标注、一致性测试问题 10 个、测试词表
│       ├── content/problems.py                15 道入门题（题面、参考解、测试数据）
│       ├── content/levels.py                  6 个关卡模板与主题包
│       └── services/validators.py, maze.py    确定性校验器、Dijkstra 最短解
├── data/
│   ├── llm_calls.jsonl        评测库里的全部 314 次大模型调用（每行一次：提示词、原始输出、耗时、token、校验结论）
│   └── embeddings.json        一致性实验 91 个不同回答的 bge-m3 向量（1024 维）
├── results/                   报告引用的原始实验输出（star_eval 当时写出的 summary.json + rows.csv + 运行日志）
└── replay/
    ├── replay.py              离线重放脚本
    └── requirements-replay.txt
```

`data/llm_calls.jsonl` 里有 24 次是演示数据预生成（tag=`pregen`），只用于「调用日志汇总」的总数；其余 290 次 tag 以 `eval:` 开头，是四组实验。

---

## 3. 报告的结果

| 实验 | 样本 | 对照组 | 改进组 | 结果文件 |
|---|---|---|---|---|
| 任务改造质量 | 15 道入门题 × 2 个画像 = 30 | 直接生成：格式 100%，规则通过 96.7% | 生成-校验-修复闭环：规则通过 100%，平均 1.03 次尝试 | `results/adapt-20261017-114305/` |
| 平均句长 | 同上 | 原题 22.27 字 | 改写后 7.3 字 | 同上 |
| 关卡可解率 | 50 个关卡 | 不校验：可解 100%，卡槽匹配 98%，全部规则 98% | BFS/Dijkstra 校验并重新生成：三项 100%，平均 1.02 次 | `results/levels-20261017-114528/` |
| 意图理解 | 50 条语句 | 关闭沟通特征处理：52% | 开启：98%（仿说 20%→100%，代词逆转 80%→93.3%，自创词 30%→100%，普通 80%→100%） | `results/intent-20261017-114750/` |
| 回答一致性 | 10 个问题 × 5 次 | 默认温度无缓存：0.83 | 低温度 0.92；低温度加缓存 1.00 | `results/consistency-20261017-115251/` |
| 调用日志汇总 | 全部调用 | — | 314 次，257,504 token（P2 106 次、P3 208 次） | `results/logs-20261017-115252/` |

---

## 4. 离线重放是怎么做的、核对了什么

`replay/replay.py` 不重新实现任何指标，而是**直接执行评测时的实验代码**：

1. 用 `source/` 启动 Django（临时 SQLite 库，进程结束即删除），并清空所有 Key，保证不会发出网络请求；
2. 把 `star.services.llm.chat_json`（全部大模型调用的唯一入口）换成「录音机」：按调用顺序返回 `data/llm_calls.jsonl` 里录下的原始输出、耗时和 token；
3. 调用 `star_eval` 的 `run_adapt / run_levels / run_intent / run_consistency / run_logs`。于是下列计算都在本机重新做一遍：
   - JSON 解析与结构校验、句长 / 步骤数 / 答案唯一 / 代码行来源等规则校验（`validators.py`）；
   - 关卡模拟与 Dijkstra 最短解、卡槽数匹配（`maze.py`）；
   - 「生成-校验-修复」循环何时停止、尝试了几次（`adapt.run_loop`）；
   - 意图比对与准确率、仿说检测、词表替换、求助护栏（`assistant.py`）；
   - 一致性实验的两两余弦相似度（向量来自 `data/embeddings.json`）；
4. 把复算结果与 `results/` 逐项、逐行逐格比对。

**录音本身也被核对**：每次回放前，都比对源码这一次拼出的提示词（messages 全文、温度、max_tokens、第几次尝试）与录下来的是否完全一致。290 次全部逐字一致，说明这些输出确实是这份代码、这些测试数据产生的；录音条数也恰好用完，没有多也没有少。

**它能发现篡改**：我们把一条意图实验的模型输出改掉一个字段再重放，意图实验的 2 项指标随即对不上，脚本退出码为 1。

**唯一的容差**：一致性实验的相似度依赖 Embedding 服务。`data/embeddings.json` 里的向量是评测之后（2026-10-17 17:08）用同一模型 BAAI/bge-m3 重新取的，服务端不保证逐位一致，30 行里有 5 行的平均相似度差 0.0001–0.0003。「默认温度无缓存」组的均值报告时为 0.82500、重放为 0.82498，恰好跨过四舍五入的边界，两位小数显示为 0.83 / 0.82。因此只对这几项相似度按容差比对（逐行 0.001，两位小数的汇总 0.01），在 `compare.md` 里标「≈」；其余所有数字都要求完全相同。现在向量已经随包固定，之后每次重放的结果都是确定的。

本机实测输出：

```
== adapt ==        指标 15/15 一致；逐行 450/450 格一致
== levels ==       指标 10/10 一致；逐行 650/650 格一致
== intent ==       指标 18/18 一致；逐行 550/550 格一致
== consistency ==  指标 7/7 一致；逐行 180/180 格一致（其中 5 格在容差内）
== logs ==         指标 7/7 一致；逐行 64/64 格一致
回放 290 次调用；提示词不一致 0 次；剩余 0 次
```

---

## 5. B 单元测试 / C 在线重跑

**B 单元测试**（在 `source/` 目录，不需要 MySQL）：

```bash
pip install -r requirements.txt          # mysqlclient 装不上可以去掉这一行，SQLite 模式用不到
# Windows PowerShell 先执行： $env:DB_ENGINE="sqlite"; $env:SECRET_KEY="test"
DB_ENGINE=sqlite SECRET_KEY=test python manage.py test judge star     # 232 个，9 个跳过
python -m unittest discover -s star/skills/tests -t .                  # 32 个，1 个跳过
node frontend/scripts/check-maze.mjs                                   # 前后端卡片规则一致：15/15
```

跳过的用例需要 Docker 沙箱或 pypinyin，与实验无关。

**C 在线重跑**（在 `source/` 目录）：

```bash
# 在 source/.env 里填写（可参考 .env.example）：
#   SECRET_KEY=任意字符串   DB_ENGINE=sqlite
#   LLM_API_KEY / LLM_API_URL（完整的 .../chat/completions 地址）/ LLM_MODEL
#   EMBED_API_KEY / EMBED_API_URL / EMBED_MODEL（一致性实验用；不填则退回字符相似度）
python manage.py migrate
python manage.py star_eval all            # 四组实验，结果写入 star_eval_results/
python manage.py star_eval logs           # 调用日志汇总
python manage.py star_eval adapt --limit 2   # 先小规模试跑、估算成本
```

在线重跑会真实调用模型，输出有随机性，数字会在报告值附近浮动。评测时用的是 `deepseek-chat`，接口别名背后的模型版本可能已更新。整套约 290 次调用、21.5 万 token、12 分钟。

---

## 6. 评测环境与数据来源

| 项 | 内容 |
|---|---|
| 评测时间 | 2026-10-17 11:40:49 – 11:52:50（UTC+8） |
| 源码版本 | 分支 `feat/star-integration`，commit `427abcb87813871a3596a8e4e791b9e08eafc35a`（2026-10-16 20:16）。评测所用 Docker 镜像里的实验相关文件与该 commit 逐个比对一致 |
| 运行环境 | 本机 Docker Desktop 生产编排（gunicorn + MySQL 8.4 + Redis 7），容器内 Python 3.11 |
| 生成模型 | DeepSeek `deepseek-chat`，OpenAI 兼容接口，JSON 输出；温度 0.2（一致性实验对照组 1.0） |
| Embedding | 硅基流动 `BAAI/bge-m3`，1024 维 |
| 对照组取法 | 配对设计：闭环第 1 次尝试的输出就是一次「直接生成」（同一提示词、模型、温度），直接作为对照组 |
| 隐私 | 提示词里学习者姓名在出平台前已替换为 `{name}`；实验用的学习者画像都是虚构的；数据里没有任何 Key |

之后的开发（任务推荐、表达记忆等）改动了部分提示词与校验器，但没有重跑实验，所以报告的数字对应的是上面这个版本。本包的 `source/` 也是这个版本。

---

## 7. 已知局限（如实说明）

- **意图标注未经人工逐条核对**：`source/star/content/eval_cases.py` 里 `REVIEWED = False`，50 条语句与标注由开发者起草；意图实验的 98% 只代表「在这批语句上」的准确率，结果文件里也标了这一点；
- **样本量小**：改造 30、关卡 50、意图 50、一致性 10 × 5，不足以支撑统计显著性结论；
- **离线重放验证的是「计算过程」**：它证明报告的数字确实由这些模型输出、经这份代码算出，不能证明换一次调用模型还会给出同样的输出——那需要 C 级在线重跑；
- **Embedding 向量是评测后重取的**：见 §4 的容差说明。

---

## 8. 文件校验

`SHA256SUMS.txt` 列出了包内每个文件的 SHA-256。校验：

```bash
sha256sum -c SHA256SUMS.txt                                   # Linux / Git Bash
```
