@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo 正在创建虚拟环境 .venv ...
  python -m venv .venv || goto :fail
)
echo 正在安装依赖 ...
.venv\Scripts\python.exe -m pip install -q --disable-pip-version-check -r replay\requirements-replay.txt || goto :fail
set PYTHONIOENCODING=utf-8
.venv\Scripts\python.exe replay\replay.py
echo.
echo 详细对照见 replay_output\compare.md
pause
exit /b 0
:fail
echo 运行失败：请确认已安装 Python 3.10 以上版本，并能访问 PyPI。
pause
exit /b 1
